C:\Users\Public\sunc_x\target\release\sUNC_x.exe: C:\Users\Public\sunc_x\src\main.rs
